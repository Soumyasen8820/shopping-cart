create table userregistration
(
userid int identity(1,1) Primary Key,
firstname varchar(100),
lastname varchar(100),
contact varchar(100),
gender varchar(100),
addressdetail varchar(100),
username varchar(100),
password varchar(100)
)

create proc useraddoredit
@userid int,
@firstname varchar(100),
@lastname varchar(100),
@contact varchar(100),
@gender varchar(100),
@addressdetail varchar(100),
@username varchar(100),
@password varchar(100)
as
if @userid=0
begin
insert into userregistration (firstname,lastname,contact,gender,addressdetail,username,password)
values (@firstname,@lastname,@contact,@gender,@addressdetail,@username,@password)
end

else
begin
update userregistration 
set
firstname=@firstname,
lastname=@lastname,
contact=@contact,
gender=@gender,
addressdetail=@addressdetail,
username=@username,
password=@password

where userid=@userid
end

create proc userviewbyid
@userid int
as
 select * from userregistration 
 where userid=@userid