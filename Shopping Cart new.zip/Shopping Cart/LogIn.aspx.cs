﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Shopping_Cart2
{
    public partial class LogIn : System.Web.UI.Page
    {
        string connectionString = @"Data Source=ndamssql\sqlilearn; Initial Catalog=Training_19Sep18_Pune; user id=sqluser ; password=sqluser ";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                clear();
                if (!string.IsNullOrEmpty(Request.QueryString["id"]))
                {
                    int UserID = Convert.ToInt32(Request.QueryString["id"]);
                    using (SqlConnection sqlCon = new SqlConnection(connectionString))
                    {
                        sqlCon.Open();
                        SqlDataAdapter sqlDa = new SqlDataAdapter("userviewbyid", sqlCon);
                        sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
                        sqlDa.SelectCommand.Parameters.AddWithValue("@userid", UserID);
                        DataTable dtbl = new DataTable();
                        sqlDa.Fill(dtbl);

                        hfUserID.Value = UserID.ToString();
                        txtFirstName.Text = dtbl.Rows[0][1].ToString();
                        txtLastName.Text = dtbl.Rows[0][2].ToString();
                        txtContact.Text = dtbl.Rows[0][1].ToString();
                        ddlGender.Items.FindByValue(dtbl.Rows[0][4].ToString()).Selected = true;
                        txtAddress.Text = dtbl.Rows[0][5].ToString();
                        txtUsername.Text = dtbl.Rows[0][6].ToString();
                        txtPassword.Text = dtbl.Rows[0][7].ToString();
                        txtPassword.Attributes.Add("value", dtbl.Rows[0][7].ToString());
                        txtConfirmPassword.Text = dtbl.Rows[0][8].ToString();
                        txtConfirmPassword.Attributes.Add("value", dtbl.Rows[0][8].ToString());

                    }
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "")
                lblErrorMessage.Text = "Please fill the mandatory field";
            else if (txtPassword.Text != txtConfirmPassword.Text)
                lblErrorMessage.Text = "Password donot match";
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("useraddoredit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@userid", Convert.ToInt32(hfUserID.Value == "" ? "0" : hfUserID.Value));
                    sqlCmd.Parameters.AddWithValue("@firstname", txtFirstName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@lastname", txtLastName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@contact", txtContact.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@gender", ddlGender.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@addressdetail", txtAddress.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    clear();
                    lblSuccessMessage.Text = "submitted successfully";
                    Response.Redirect("Default.aspx");

                }
            }
        }
        void clear()
        {
            txtFirstName.Text = txtLastName.Text = txtContact.Text = txtAddress.Text = txtPassword.Text = txtUsername.Text = txtConfirmPassword.Text = "";
            hfUserID.Value = "";
            lblSuccessMessage.Text = lblErrorMessage.Text = "";
        }
    }
}